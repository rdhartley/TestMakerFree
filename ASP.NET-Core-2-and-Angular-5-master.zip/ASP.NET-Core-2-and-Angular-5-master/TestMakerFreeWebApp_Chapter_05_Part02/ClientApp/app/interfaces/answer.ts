interface Answer {
    Id: number;
    QuestionId: number;
    Text: string;
    Value: number;
}
